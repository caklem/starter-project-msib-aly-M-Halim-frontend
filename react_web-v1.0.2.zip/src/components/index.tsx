import { Text } from "./Text";
import { Heading } from "./Heading";
import { Button } from "./Button";
import { Img } from "./Img";
import { Input } from "./Input";
export { Text, Heading, Button, Img, Input };
